﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Delete_Account : Form
    {
        string user;
        public Delete_Account(string username)
        {
            user = username;

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int pin = 0;


            if (int.TryParse(textBox1.Text, out pin))
            {

                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "' AND Pin='" + pin + "'", conn);

                    DataTable dt = new DataTable();

                    sda.Fill(dt);

                    if (dt.Rows[0][0].ToString() == "1")
                    {

                        SqlCommand cmd = new SqlCommand("delete from Where Username='" + user + "';", conn);

                        SqlDataReader reader;


                        try
                        {

                            conn.Open();

                            reader = cmd.ExecuteReader();

                            MessageBox.Show("Account has been deleted", " Account");

                            while (reader.Read())
                            {


                            }

                            this.Hide();

                            Form1 LG = new Form1();

                            LG.Show();

                        }

                        catch (Win32Exception ex)
                        {

                            MessageBox.Show("Account has not been deleted", "Error");
                        }

                    }

                    else
                    {

                        MessageBox.Show("Pin number don't match Username: " + user, "Invalid Pin");
                    }
                }

            }


            else
            {

                MessageBox.Show("Your input is invalid. Please enter a valid input", "Error Message");
            }
        }
    }
}
