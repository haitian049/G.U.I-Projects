﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Pass_Change : Form
    {
        string user;

        public Pass_Change(string username)
        {
            user = username;

            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Checking chk = new Checking(user);

            chk.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30");

            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'and Password = '" + textBox1.Text + "'", conn);

            DataTable dt = new DataTable();

            sda.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {

                if (textBox2.Text == textBox3.Text)
                {


                    SqlCommand cmd = new SqlCommand("UPDATE CLIENT SET Password='" + textBox2.Text + "' Where Username='" + user + "'", conn);

                    SqlDataReader reader;

                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {


                        }

                        reader.Close();

                        conn.Close();

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Password Change Failed", "Error");
                    }
                }

                else
                {
                    MessageBox.Show("New Password's don't match. Please  make they match before you submit ","Invalid Password");
                }
            }

            else
            {
                MessageBox.Show("Old password is not correct. Please try again", "Incorrect Password");
            }
        }
    }
}
