﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Forgotten_Password : Form
    {
        public Forgotten_Password()
        {
            InitializeComponent();
        }
        string password;

        private void button1_Click(object sender, EventArgs e)
        {

            int pin = 0;



            if (int.TryParse(textBox2.Text, out pin))
            {

                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + textBox1.Text + "' AND Pin='" + pin + "'", conn);

                    DataTable dt = new DataTable();

                    sda.Fill(dt);

                    if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                    {


                        SqlCommand cmd = new SqlCommand("select Password from Client Where Username='" + textBox1.Text + "';", conn);

                        SqlDataReader reader;


                        try
                        {

                            conn.Open();

                            reader = cmd.ExecuteReader();

                            while (reader.Read())
                            {
                                // Stores the Balance from the sql database colomn Balance

                                password = reader["Password"].ToString();


                            }

                        }

                        catch (Win32Exception ex)
                        {

                            MessageBox.Show("Failed to retrieve data from database", "Error");
                        }


                        SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587); // Using google sever and using port 587 since google do use 25

                        NetworkCredential basicCredential = new NetworkCredential("acherubin86@gmail.com", "buddah98");

                        MailMessage message = new MailMessage();

                        MailAddress fromAddress = new MailAddress("acherubin86@gmail.com"); // From email address

                        smtpClient.UseDefaultCredentials = false;

                        smtpClient.Credentials = basicCredential; // Assigning your Credentials(Username and Password) to authenicatae use of server

                        smtpClient.EnableSsl = true; // Enables SSL

                        message.From = fromAddress;

                        message.Subject = "your subject";

                        //Set IsBodyHtml to true means you can send HTML email.

                        message.IsBodyHtml = false;

                        message.Body = "Your password is " + password;

                        message.To.Add(textBox3.Text); // Tp email address(email address that the user will enter

                        try
                        {
                            smtpClient.Send(message);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Invalid email address", "Message not sent");
                        }


                    }

                    else
                    {

                        MessageBox.Show("Pin number don't match Username: " + textBox1, "Invalid Pin");
                    }
                }

            }


            else
            {

                MessageBox.Show("Your input is invalid. Please enter a valid input", "Error Message");
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Form1 LG = new Form1();

            LG.Show();
        }
    }
}
