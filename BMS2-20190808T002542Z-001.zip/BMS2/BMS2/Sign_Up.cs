﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Sign_Up : Form
    {
        public Sign_Up()
        {
            InitializeComponent();
        }
        Form1 LOGIN = new Form1();

        Random rand = new Random();

        float balance = 0;

       
        private void button1_Click(object sender, EventArgs e)
        {
            int account = 0001 + rand.Next(1, 1000);

            if (label1.ForeColor == System.Drawing.Color.Green)
            {

                if ((textBox9.Text == textBox11.Text)&&(float.TryParse(textBox8.Text, out balance)))
                {


                    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30");

                    SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");

                    conn1.Open();

                    SqlCommand cmd = new SqlCommand("insert into CLIENT (Account#, Name, Address, City, State, Phone, Type, Balance, Pin, Username, Password) Values('" + account + "', '" + this.textBox1.Text + "', '" + this.textBox2.Text + "', '" + this.textBox3.Text + "', '" + this.comboBox1.Text + "', '" + this.textBox5.Text + "', '" + this.comboBox2.Text + "', '" + this.textBox8.Text + "', '" + this.textBox7.Text + "', '" + this.textBox10.Text + "', '" + this.textBox9.Text + "');", conn);

                    SqlCommand m = new SqlCommand("insert into LOGIN(Account, Debit, Credit, Description) values(@Account, @Debit, @Credit, @Description)", conn1);

                    SqlDataReader reader;


                    m.Parameters.AddWithValue("@Account", (0001+rand.Next(1,1000)));
                    m.Parameters.AddWithValue("@Debit", balance);
                    m.Parameters.AddWithValue("@Credit", 0);
                    m.Parameters.AddWithValue("@Description", Description);

                    m.ExecuteNonQuery();

                    MessageBox.Show("Transaction Updated", "Success");

                      try
                      {

                          conn.Open();

                          reader = cmd.ExecuteReader();
                          MessageBox.Show("Saved", "New Customer Added");
                          while (reader.Read())
                          {


                          }

                      }

                      catch (System.Exception ex)
                      {

                          MessageBox.Show("Update failed");

                      }

                      this.Hide(); // Hides the current Form 

                      LOGIN.Show(); // Show the Login Window
                          /* 
                      SqlCommand comm = new SqlCommand("INSERT INTO CLIENT (Account#, Name, Address, City, State, Phone, Type, Balance, Pin, Username, Password) Values(, @Name, @Address, @City, @State, @Phone, @Type, @Balance, @Pin, @Username, @Password)", conn);

                      comm.Parameters.AddWithValue("@Account#", int.Parse(account_TextBox.Text));
                      comm.Parameters.AddWithValue("@Name", nameTextBox.Text);
                      comm.Parameters.AddWithValue("@Address", addressTextBox.Text);
                      comm.Parameters.AddWithValue("@City", cityTextBox.Text);
                      comm.Parameters.AddWithValue("@State", stateComboBox.Text);
                      comm.Parameters.AddWithValue("@Phone", int.Parse(phoneTextBox.Text));
                      comm.Parameters.AddWithValue("@Type", typeComboBox1.Text);
                      comm.Parameters.AddWithValue("@Balance", balanceTextBox.Text);
                      comm.Parameters.AddWithValue("@Pin", int.Parse(pinTextBox.Text));
                      comm.Parameters.AddWithValue("@Username", usernameTextBox1.Text);
                      comm.Parameters.AddWithValue("@Password", passwordTextBox1.Text);

                      comm.ExecuteNonQ
                   */
                    

                }

                else
                {

                    MessageBox.Show("Both passwords does not match, please re-enter both passwords again", "Failed Password");
                }

            }

            else
            {

                MessageBox.Show("Please use a USERNAME that is available", "Failed Username");

            }
        }
        string Description = " NEW ACCOUNT";
        
        int credit = 0;
        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30");

            SqlDataAdapter sda = new SqlDataAdapter("Select count(*) From Client Where Username='" + textBox10.Text + "'", conn);

            DataTable dt = new DataTable();

            sda.Fill(dt);

            if (int.Parse(dt.Rows[0][0].ToString()) == 0)
            {

                label1.Text = textBox10.Text + " is Available";
                this.label1.ForeColor = System.Drawing.Color.Green;
            }

            else
            {

                label1.Text = textBox10.Text + " is Not Available";
                this.label1.ForeColor = System.Drawing.Color.Red;
            }


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            LOGIN.Show();
        }
    }
}
