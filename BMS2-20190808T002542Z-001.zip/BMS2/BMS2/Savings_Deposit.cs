﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Savings_Deposit : Form
    {
        string user;

        public Savings_Deposit(string username)
        {
            user = username;

            InitializeComponent();
        }

        double Curr_Bal = 0.0, Curr_Bal2 = 0.0;
        private void Savings_Deposit_Load(object sender, EventArgs e)
        {

            label1.Text = user;

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'", conn);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                {

                    SqlCommand cmd = new SqlCommand("select  Balance from Client Where Username='" + user + "';", conn);

                    SqlDataReader reader;


                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            // Stores the Balance from the sql database colomn Balance

                            label5.Text = reader["Balance"].ToString();

                            Curr_Bal = Convert.ToDouble(reader["Balance"]);

                        }

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Failed to retrieve data from database", "Error");
                    }

                }

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
             label1.Text = user;

            float increase = 0;

            if(float.TryParse(this.textBox1.Text, out increase))
           
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
            {
               string commandText = "UPDATE Client SET Balance='" + (increase + Curr_Bal) + "' Where Username='" + this.label1.Text + "';";

                SqlCommand cmd = new SqlCommand(commandText, conn);

                SqlDataReader reader;


                try
                {

                    conn.Open();

                    reader = cmd.ExecuteReader();
                    
                    MessageBox.Show("Balance has been Updated", "Checking Account");
                    
                    while (reader.Read())
                    {


                    }

                }

                catch(Win32Exception ex)
                {

                    MessageBox.Show("Update Failed");
                }
            }

            else
            {

                MessageBox.Show("The input is not valid. Please try agian ", "Incorrect input");
            }
        
        
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Savings sa = new Savings(user);

            sa.Show();

        }
    }
}
