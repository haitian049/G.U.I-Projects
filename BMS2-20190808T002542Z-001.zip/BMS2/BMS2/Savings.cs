﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMS2
{
    public partial class Savings : Form
    {
        string user;

        public Savings(string username)
        {
            user = username;

            InitializeComponent();
        }

        private void Savings_Load(object sender, EventArgs e)
        {
            label1.Text += user;

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Savings_Deposit SD = new Savings_Deposit(user);

            SD.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Form1 LOGIN = new Form1();

            LOGIN.Show();

        }
    }
}
