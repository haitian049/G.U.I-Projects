﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Account_Summary : Form
    {
        string user;

        public Account_Summary(string username)
        {
            user = username;

            InitializeComponent();
        }

        private void Account_Summary_Load(object sender, EventArgs e)
        {
            double Curr_Bal = 0.0;

            label2.Text = user;

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'", conn);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                {


                    SqlCommand cmd = new SqlCommand("Select Account#, Balance From Client Where Username='" + user + "';", conn);

                    SqlDataReader reader;


                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {

                            label6.Text = reader["Account#"].ToString();

                            Curr_Bal = Convert.ToDouble(reader["Balance"]);

                            label4.Text += Curr_Bal.ToString();
                        }

                        reader.Close();

                        conn.Close();
                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Failed to retrieve data from database", "Error");

                    }

                }

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Checking chk = new Checking(user);

            chk.Show();

        }
    }
}
