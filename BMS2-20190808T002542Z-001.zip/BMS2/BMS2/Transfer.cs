﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace BMS2
{
    public partial class Transfer : Form
    {
        public Transfer(string username)
        {
            user = username;
            InitializeComponent();
        }

        string user;

        double Curr_Bal = 0.0, Curr_Bal2 = 0.0;

        private void button1_Click(object sender, EventArgs e)
        {

            label2.Text = user;

            int account = 0;

            float Amount = 0;

            double New_Balance = 0.0;

            string commandText, commandText2, commandText3;

            if ((int.TryParse(this.textBox1.Text, out account) && float.TryParse(numericUpDown1.Text, out Amount)) && (Amount > Curr_Bal))
            {
                SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");

                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30");

                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Account#='" + account + "'", conn);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1")
                {
                    SqlCommand cmd = new SqlCommand("select  Balance from Client Where Account#='" + account + "';", conn);

                    SqlDataReader reader;


                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            // Stores the Balance from the sql database colomn Balance

                            Curr_Bal = Convert.ToDouble(reader["Balance"]);

                        }

                        reader.Close();

                        conn.Close();
                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Failed to retrieve data from database", "Error");
                    }

                    New_Balance = Curr_Bal2 - Amount;

                    //Updating the account that is recieving the transfer by taking the amount to be transfered and adding it to the current balance of the
                    commandText = "UPDATE Client SET Balance='" + (Amount + Curr_Bal) + "' Where Account#='" + account + "';";

                    //Updating the users account by taking the users current balance and subtracting it from the amount transfered
                    commandText2 = "UPDATE Client SET Balance='" + (New_Balance) + "' Where Username='" + user + "';";

                    SqlCommand cmd1 = new SqlCommand(commandText, conn);

                    SqlCommand cmd2 = new SqlCommand(commandText2, conn);

                    string Description = "A transfer amount of" + Amount.ToString() + "to " + account.ToString();

                    SqlCommand m = new SqlCommand("insert into LOGIN(Account, Debit, Credit, Description) values(@Account, @Debit, @Credit, @Description)", conn1);

                    conn1.Open();

                    m.Parameters.AddWithValue("@Account", account);
                    m.Parameters.AddWithValue("@Debit", 0);
                    m.Parameters.AddWithValue("@Credit", Amount);
                    m.Parameters.AddWithValue("@Description", Description);

                    m.ExecuteNonQuery();

                    try
                    {

                        conn.Open();

                        reader = cmd1.ExecuteReader();

                        while (reader.Read())
                        {


                        }

                        reader.Close();

                        conn.Close();

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Update Failed");
                    }

                    try
                    {

                        conn.Open();

                        reader = cmd2.ExecuteReader();

                        MessageBox.Show("Transfer Complete", "Checking Account");

                        while (reader.Read())
                        {


                        }

                        reader.Close();

                        conn.Close();

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Transfered Failed");
                    }


                }

                else
                {

                    MessageBox.Show("The Account number is not valid or the amount being transfered exceeds current balance. Please try agian ", "Invalid Account");
                }
            }

            else
            {

                MessageBox.Show("The input is not valid. Please try agian ", "Incorrect input");
            }

        }

        private void Transfer_Load(object sender, EventArgs e)
        {

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'", conn);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                {

                    SqlCommand cmd = new SqlCommand("select  Balance from Client Where Username='" + user + "';", conn);

                    SqlDataReader reader;


                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            // Stores the Balance from the sql database colomn Balance

                            Curr_Bal2 = Convert.ToDouble(reader["Balance"]);

                        }

                        reader.Close();

                        conn.Close();

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Failed to retrieve data from database", "Error");
                    }

                    label5.Text = Curr_Bal2.ToString();
                }

            }


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Checking chk = new Checking(user);

            chk.Show();
        }
    }
}
