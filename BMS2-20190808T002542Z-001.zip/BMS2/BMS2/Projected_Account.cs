﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Projected_Account : Form
    {
        string user;

        public Projected_Account(string username)
        {
            user = username;

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            double Principal = 0;

            double Interest_Rate = 0;

            double time = 0.0;

            double PA = 0.0;

            double Balance = 0.0;

            bool result1 = double.TryParse(numericUpDown1.Text, out Principal);

            bool result2 = double.TryParse(numericUpDown2.Text, out Interest_Rate);

            bool result3 = double.TryParse(numericUpDown3.Text, out time);

            if ((result1 && result2 && result3) && !((Principal * Interest_Rate * time) <= 0))
            {

                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'", conn);

                    DataTable dt = new DataTable();

                    sda.Fill(dt);

                    if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                    {

                        SqlCommand cmd = new SqlCommand("select  Balance from Client Where Username='" + user + "';", conn);

                        SqlDataReader reader;


                        try
                        {

                            conn.Open();

                            reader = cmd.ExecuteReader();

                            while (reader.Read())
                            {
                                // Stores the Balance from the sql database colomn Balance

                                Balance = 1 + (Interest_Rate) / 100;

                                PA = Principal * Math.Pow((Balance), time);

                                label7.Text = System.Math.Round(Convert.ToDecimal(PA), 2).ToString();
                            }

                        }

                        catch (Win32Exception ex)
                        {

                            MessageBox.Show("Failed to retrieve data from database", "Error");
                        }

                    }

                    else
                    {

                        MessageBox.Show("Failed attempt match Username: " + user, "Invalid Username");
                    }
                }

            }


            else
            {

                MessageBox.Show("Your input is invalid. Please enter a valid input", "Error Message");
            }


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            this.Hide();

            Checking chk = new Checking(user);

            chk.Show();
        }

        private void Projected_Account_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'", conn);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                {

                    SqlCommand cmd = new SqlCommand("select  Balance from Client Where Username='" + user + "';", conn);

                    SqlDataReader reader;


                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            // Stores the Balance from the sql database colomn Balance

                            label6.Text = reader["Balance"].ToString();
                        }

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Failed to retrieve data from database", "Error");
                    }

                }

                else
                {

                    MessageBox.Show("Failed attempt match Username: " + user, "Invalid Username");

                }
            }
        }
    }
}
