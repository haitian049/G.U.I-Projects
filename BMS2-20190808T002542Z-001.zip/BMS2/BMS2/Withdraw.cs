﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Withdraw : Form
    {
        public Withdraw(string username)
        {
            user = username;

            InitializeComponent();
        }
        string user;

        double Curr_Bal = 0;

        int account = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = user;

            double decrease = 0.0;

            if (double.TryParse(this.textBox1.Text, out decrease))
            {
                if (!(decrease > Curr_Bal))
                {
                    double total_withdrawal = Curr_Bal - decrease;

                    string Description = "Withdrawal was made in the amount of " + decrease.ToString();

                    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30");

                    SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");

                    string commandText = "UPDATE Client SET Balance='" + (Curr_Bal - decrease) + "' Where Username='" + this.label1.Text + "';";

                    SqlCommand cmd = new SqlCommand(commandText, conn);

                    /* SqlCommand m = new SqlCommand("insert into LOGIN(Account, Debit, Credit, Description) values(@Account, @Debit, @Credit, @Description)", conn1);



                     conn1.Open();

                     m.Parameters.AddWithValue("@Account", account);
                        
                     m.Parameters.AddWithValue("@Debit", 0);
                        
                     m.Parameters.AddWithValue("@Credit", decrease);
                    
                     m.Parameters.AddWithValue("@Description", Description);

                         m.ExecuteNonQuery();
                      */
                    SqlDataReader reader;

                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        MessageBox.Show("Balance has been Updated", "Checking Account");

                        while (reader.Read())
                        {


                        }

                        reader.Close();

                        conn.Close();

                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Update Failed");
                    }

                }


                else
                {

                    MessageBox.Show("The withdraw amount exceeds your current account balance. Please try agian ", "Insufficent Funds");
                }

            }
            else
            {

                MessageBox.Show("The input is not valid. Please try agian ", "Incorrect input");
            }
        }

        private void Withdraw_Load(object sender, EventArgs e)
        {

            label1.Text = user;

            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + user + "'", conn);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1") // if the user is logged in then it will be 
                {


                    SqlCommand cmd = new SqlCommand("select Account#, Balance from Client Where Username='" + user + "';", conn);

                    SqlDataReader reader;


                    try
                    {

                        conn.Open();

                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            // Stores the Balance from the sql database colomn Balance

                            label5.Text = reader["Balance"].ToString();

                            account = Convert.ToInt32(reader["Account#"]);

                            Curr_Bal = Convert.ToDouble(reader["Balance"]);

                        }

                        reader.Close();

                        conn.Close();
                    }

                    catch (Win32Exception ex)
                    {

                        MessageBox.Show("Failed to retrieve data from database", "Error");
                    }

                }
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Checking chk = new Checking(label1.Text);

            chk.Show();
        }
    }
}
