﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BMS2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Danielle\Documents\Client.mdf;Integrated Security=True;Connect Timeout=30");

            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Client where Username='" + textBox1.Text + "'and Password = '" + textBox2.Text + "' and Type = '" + comboBox1.Text + "'", conn);

            DataTable dt = new DataTable();

            sda.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {

                SqlDataAdapter sda1 = new SqlDataAdapter("Select Count(*) From Client where Username='" + textBox1.Text + "'and Password= '" + textBox2.Text + "'", conn);

                DataTable dt1 = new DataTable();

                sda1.Fill(dt1);

                if (comboBox1.Text == "CHECKING")
                {
                    this.Hide();

                    Checking CHK = new Checking(textBox1.Text);

                    CHK.Show();

                }

                else if (comboBox1.Text == "SAVINGS")
                {

                    this.Hide();

                    Savings SAV = new Savings(textBox1.Text);

                    SAV.Show();
                }

            }

            else
            {

                MessageBox.Show("Please check your Username or Password", "Error Message");

            }


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Sign_Up mf = new Sign_Up();

            mf.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Forgotten_Password FP = new Forgotten_Password();

            FP.Show();
        }
    }
}
