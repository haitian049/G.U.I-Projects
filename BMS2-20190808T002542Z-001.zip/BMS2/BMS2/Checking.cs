﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMS2
{
    public partial class Checking : Form
    {
        string user;
        public Checking(string username)
        {
            user = username;

            InitializeComponent();
        }

        private void Checking_Load(object sender, EventArgs e)
        {
            label2.Text += user;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Deposit DP = new Deposit(user);

            DP.Show();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
        
            this.Hide();

            Withdraw WD = new Withdraw(user);

            WD.Show();

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            this.Hide();

            Projected_Account PA = new Projected_Account(user);

            PA.Show();

        }

        private void linkLabel10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
        
            this.Hide();

            Transfer Trans = new Transfer(user);

            Trans.Show();
        }

        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Pass_Change pass = new Pass_Change(user);

            pass.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Delete_Account D = new Delete_Account(user);

            D.Show();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Form1 LOGIN = new Form1();

            LOGIN.Show();

        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            Account_Summary AS = new Account_Summary(user);

            AS.Show();
        }

    }
}
