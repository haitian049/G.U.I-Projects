
import java.text.DateFormat;
import java.util.*;

/**
 * The class represents an inventory of items that each have a quantity and a critical date. The list explicitly keeps
 * track of both the quantity and critical date for every item. No item in the inventory ever has a null date or
 * non-positive quantity. In the inventory, items are identified by both the item object and their date and .equals is
 * used to compare items and dates. (Items that are the same but have different critical dates are kept separately in
 * the inventory.)
 * 
 * @author Peter Jensen
 * @version May 27, 2010
 */
public class Inventory<I extends Item>
{
    
    // Instance variables
    
    protected List<DatedItem> inventory;

    /* Constructor */

    /**
     * Builds an empty inventory.
     */
    public Inventory ()
    {
        inventory = new ArrayList<DatedItem>();
    }
    
    /**
     * Returns all the item
     * @return
     */
    public Set<I> getAllItems() {
        Set<I> set = new HashSet<I>();
        for (DatedItem i : inventory)
            set.add(i.item);
        return set;
    }
    
    /**
     * Returns all the quantity
     * @return
     */
    public int getAllQuanity() {
        int sum = 0;
        for (DatedItem i : inventory)
            sum += i.quantity;
        return sum;
    }
    
    /**
     * Returns all the quantity by name
     * @return
     */
   /* public Map<String, Inventory.FoodItem> getAllDateItemMap() 
    {
        
        Map<String, I> map = (Map<String, I>) new TreeMap<String, Inventory.FoodItem>();
        
        for (DatedItem i : inventory) 
        {
            I item = i.item;
            
            map.put(item.getUpcCode, item);
            
        }
        
        return map;
        
    }*/
    
    /**
     * Adds an item to the inventory with the specified critical date and quantity. The item and date must be non-null
     * and the quantity must be positive or no action is taken. If the item already exists with the specified critical
     * date in the inventory, the quantity for that item (and date) will be increased by the specified quantity.
     * 
     * @param item
     *            an item
     * @param criticalDate
     *            a date
     * @param quantity
     *            a positive item count
     * 
     */
    public void addItem(I item, GregorianCalendar criticalDate, int quantity)
    {
        // Check for invalid parameters.
        
        if (item == null || criticalDate == null || quantity < 1)
            return;
        
        // Make a dated item for these parameters.
        
        DatedItem d = new DatedItem (item, criticalDate, quantity);
        
        // Try to find it in the inventory.
        
        for (DatedItem i : inventory)
            if (i.isSameItemAndDate(d))
            {
                // Found it - increase quantity and quit.
                
                i.quantity += quantity;
                return;
            }
        
        // Didn't find it - add it to inventory.
        
        inventory.add(d);
    }
    
    /**
     * Reduces the quantity of an item (specified by item object and date) in the inventory by the specified quantity.
     * If the item's quantity is reduced to or below 0, the item is removed from the inventory. If the quantity is not
     * positive, or if the item or date is null, no action is taken.
     * 
     * @param item
     *            an item
     * @param criticalDate
     *            a date
     * @param quantity
     *            a positive item count
     */
    public void removeItem(I item, GregorianCalendar criticalDate, int quantity) 
    {
        // Check for invalid parameters.
        
        if (item == null || criticalDate == null || quantity < 1)
            return;
        
        // Make a dated item for these parameters.
        
        DatedItem d = new DatedItem (item, criticalDate, quantity);
        
        // Try to find it in the inventory.
        
        for (DatedItem i : inventory)
            if (i.isSameItemAndDate(d))
            {
                // Found it - decrease quantity and remove it if quantity falls below 0.
                
                i.quantity -= quantity;
                if (i.quantity < 1)
                    inventory.remove(i);
                
                return;
            }        
    }
    
    /**
     * This method returns the quantity of this item (with the specified critical date) in the inventory.
     * 
     * @param fd
     *            an item
     * @param criticalDate
     *            a date
     * @return the quantity of that item with that date in the inventory
     */
    public int getQuantity(I fd, GregorianCalendar criticalDate)
    {
        // Check for invalid parameters.
        
        if (fd == null || criticalDate == null)
            return 0;
        
        // Make a dated item for these parameters.
        
        DatedItem d = new DatedItem (fd, criticalDate, 0);
        
        // Try to find it in the inventory.
        
        for (DatedItem i : inventory)
            if (i.isSameItemAndDate(d))
                return i.quantity;// Found it - return the quantity
        
        // Not found.
        
        return 0;
    }
    
    /**
     * This method returns the critical date for the specified item in the inventory.  If multiple matching items are in
     * the inventory with different critical dates, the oldest critical date for that kind of item is returned.  If no
     * such item is found in the inventory, null is returned.
     * 
     * @param fd an item
     * @return the oldest critical date for this item
     */
    public GregorianCalendar getDate(I fd)
    {
        GregorianCalendar result = null;
        
        // Optimization loop on item dates for the specified item
        
        for (DatedItem i : inventory)
            if (i.item.equals(fd) && (result == null || i.criticalDate.before(result)))
                result = i.criticalDate;
                
        return result;
        
    }
    
    /**
     * This method returns an ArrayList of items whose critical date is before the target date. 
     * 
     * @param targetDate a date
     * @return a list of items whose critical date is before the target date
     */
    public ArrayList<I> getItemsPastDate(GregorianCalendar targetDate)
    {
        ArrayList<I> result = new ArrayList<I>();
        
        // Find all the past due items.
        
        for (DatedItem i : inventory)
            if (i.criticalDate.before(targetDate))
                result.add(i.item);
        
        return result;
    }
    
    /**
     * Programmer debugging method - not for general use.  Outputs the contents of this inventory
     * to the screen with a title label.
     */
    void outputToConsole (String inventoryName)
    {
        DateFormat formatter = DateFormat.getDateInstance();
        
        System.out.println();
        String s = "Contents of Inventory: " + inventoryName;
        System.out.println (s);
        for (int i = 0; i < s.length(); i++)
            System.out.print ('-');
        System.out.println();
        for (DatedItem i : inventory)
            System.out.printf ("Item: %-20s  Item Type: %-20s  Critical date: %13s     Quantity: %3s\n", i.item.getName(), i.item.getClass().getSimpleName(), formatter.format(i.criticalDate.getTime()), i.quantity);        
        System.out.println();
    }
    
    /**
     * Nested class to represent items with dates and quantities.
     * 
     * Equality is defined by == only.
     */
     
     
public static class FoodItem extends Item implements Comparable<FoodItem>
{
	// Instance variables.

	private String upcCode;  // Keeping the upcCode as a String simplifies the code.
	
   private int shelfLife;


	/**
	* Builds a food item with the specified name, UPC code, and shelf life (in days).
	* 
	* @param name the name of this food item
	* @param upcCode the UPC code printed on the packaging
	* @param shelfLife the number of days this item will stay fresh
	*/
	public FoodItem (String name, String upcCode, int shelfLife)
	{
		
      super(name);
		
      this.upcCode = upcCode;
		
      this.shelfLife = shelfLife;
      
	}

	/**
	* Returns the UPC code for this food item.
	* 
	* @return the UPC code for this item
	*/
   
	public String getUpcCode()
	{
		return upcCode;
	}

	/**
	* Returns the shelf life code for this food item.
	* 
	* @return the shelf life for this item
	*/
	public int getShelfLife()
	{
		return shelfLife;
	}
 


	/**
	* Given a manufacture date, this method will return the corresponding expiration date
	* for this food item.  The item expires on the beginning of the expiration date.
	* This method can be used repeatedly to compute expiration dates for different
	* manufacturing dates.
	* 
	* @param manufactureDate the date of manufacture
	* @return the expiration date
	*/
	public GregorianCalendar getExpirationDate(GregorianCalendar manufactureDate)
	{
		
      GregorianCalendar result = (GregorianCalendar) manufactureDate.clone();
		
      result.add(Calendar.DAY_OF_MONTH, shelfLife);
		
      return result;
      
	}
    
	/**
	* Compares this FoodItem to another FoodItem to determine relative order (for sorting
	* food items).  FoodItems are ordered first by name, then in the case of ties by UPC, and by shelf life last. 
	* Zero is returned if this food item is equal to the other food item.  A negative integer is returned if
	* this food item is less than the other food item.  A positive integer is returned if this food item is
	* greater than the other food item. 
	* 
	* @param other an item to compare this item to
	* @return -1, 0, or 1 if this item is less than, equal to, or greater than the other item
	*/
	public int compareTo(FoodItem other)
	{
		int result;
    
		result = name.compareTo(other.name);
		if (result != 0)
			return result;
    
		result = upcCode.compareTo(other.upcCode);
		if (result != 0)
			return result;
    
		if (this.shelfLife < other.shelfLife)
			return -1;
		else if (this.shelfLife > other.shelfLife)
			return 1;
		else
			return 0;
	}

	/**
	* Returns true if this FoodItem represents the same food item
	* as the other object, false otherwise.
	* 
	* @return true if these items represent the same food
	*/
	public boolean equals (Object other)
	{
		// If they are the same reference, they are the same item.
    
		if (this == other)
			return true;
    
		// If the other object is not a food item, they cannot be equal.
    
		if (!(other instanceof Inventory.FoodItem))
			return false;
    
		// Use the comparison method - equal if result is 0.
    
		FoodItem food = (FoodItem) other;
		    
		return this.compareTo(food) == 0;        
	}

	/**
	* Returns a hash code for this food item.  Equal food items are
	* guaranteed to have equal hash codes.
	* 
	* @return this item's hash code
	*/
	public int hashCode ()
	{
		return name.hashCode() + upcCode.hashCode() + shelfLife;
	}

	/**
	* Returns a String that describes this FoodItem object.
	* 
	* @return a String describing this object
	*/
	public String toString ()
	{
 		return "FoodItem - UPC Code: " + upcCode + "  Shelf life: " + shelfLife + "  Name: " + name;
	}
}

         
    public class DatedItem
    {
        // Instance variables
        
        private I item;
        private GregorianCalendar criticalDate;
        private int quantity;
        
        /**
         * Builds a dated item with the specified item, date, and quantity.
         * 
         * @param item
         *            an item of type I
         * @param criticalDate
         *            the critical date for this item
         * @param quantity
         *            the quantity of this item
         */
        public DatedItem (I item, GregorianCalendar criticalDate, int quantity)
        {
            this.item = item;
            this.criticalDate = criticalDate;
            this.quantity = quantity;
        }
        
        /**
         * Returns true if this dated item and the other dated item share the same items and dates.
         * 
         * @param other
         *            some other dated item
         * @return true if they are equivalent items and dates
         */
        public boolean isSameItemAndDate (DatedItem other)
        {
            return item.getName().equals(other.item.getName()) && criticalDate.equals(other.criticalDate);
        }        
    }
    
    
  



    public class FoodItemsStatistics<I extends Item>
    {
       
        // Creating a List of DatedItems to represent my FoodItemStatistics Inventory
        protected List<DatedItems> FIS_Inventory;

        /* Constructor */

        /**
         * Builds an empty inventory.
         */
        public FoodItemsStatistics ()
        {
            FIS_Inventory = new ArrayList<DatedItems>();
        }
        

    // ACCESSOR FUNCTIONS-------------------------------------------------------------------------------
       

       public List<I> getItemsPastDate(GregorianCalendar targetDate)
        {
            ArrayList<I> result = new ArrayList<I>();
            
            // Find all the past due items.
            
            for (DatedItems i : FIS_Inventory)
            
                if (i.criticalDate.before(targetDate))
                
                    result.add(i.item);
            
            return result;
        }


       public GregorianCalendar getDate(I item)
        {
            GregorianCalendar result = null;
            
            // Optimization loop on item dates for the specified item
            
            for (DatedItems i : FIS_Inventory)
            
                if (i.item.equals(item) && (result == null || i.criticalDate.before(result)))
                
                    result = i.criticalDate;
                    
            return result;
            
        }
        
        
          public Set<Item> getAllItems() 
          {
           // Created a hash set because every item in inventory is unique
            Set<Item> set = new HashSet<Item>();
            
           // Adds every item in FoodItemStatistics Inventory to the set
            for (DatedItems i : FIS_Inventory)
                set.add(i.item);
            
           // Returns the set     
            return set;
        }
        
          public int getAllQuanity() 
          {
          // Integer variable to keep count of the total amount of FoodItems in the FoodItemsStatistics_Inventory
            int Total = 0;
         
          // 
            for (DatedItems i : FIS_Inventory)
                Total += i.quantity;
                
            return Total;
        }
        
         public  List<DatedItems> getAllDatedItemMap() 
        {
            List<DatedItems> fis = FIS_Inventory;
           
            
            return fis;
            
        }
         
         
         public int getQuantity(I item, GregorianCalendar criticalDate)
         {
             // Check for invalid parameters.
             
             if (item == null || criticalDate == null)
                 return 0;
             
             // Make a dated item for these parameters.
             
             DatedItems d = new DatedItems (item, criticalDate, 0, false);
             
             // Try to find it in the inventory.
             
             for (DatedItems i : FIS_Inventory)
                 if (i.isSameItemAndDate(d))
                     return i.quantity;// Found it - return the quantity
             
             // Not found.
             
             return 0;
         }
        
    //--------------------------------------------------------------------------------------------------


       public void addItems(I item, GregorianCalendar criticalDate, int quantity, boolean isReceived)
        {
            // Check for invalid parameters.
            
            if (item == null || criticalDate == null || quantity < 1)
                return;
            
            // Make a dated item for these parameters.
            
            DatedItems d = new DatedItems (item, criticalDate, quantity, isReceived);
            
            // Try to find it in the inventory.
            
            for (DatedItems i : FIS_Inventory)
                // If an item is being received 
                if (i.isSameItemAndDate(d) && i.isRec)
                {
                    // Found it - increase quantity and quit.
                    
                    i.quantity += quantity;
                    
                    i.Stock_Received += quantity;
                    
                    return;
                }
                
                // or If an item is being requested
                else if (i.isSameItemAndDate(d) && !(i.isRec))
                {
                
                    i.Stock_Requested += quantity;
                    
                     i.Stock_Shipped_Out += quantity;                        
                    
                    return;
                }           
            
            // Didn't find it - add it to inventory.
            
            FIS_Inventory.add(d);
        }


       public void removeItems(I item, GregorianCalendar criticalDate, int quantity) 
       {
           // Check for invalid parameters.
           
           if (item == null || criticalDate == null || quantity < 1)
               return;
           
           // Make a dated item for these parameters.
           
           DatedItems d = new DatedItems (item, criticalDate, quantity, false);
           
           // Try to find it in the inventory.
           
           for (DatedItems i : FIS_Inventory)
               if (i.isSameItemAndDate(d))
               {
                   // Found it - decrease quantity and remove it if quantity falls below 0.
                   
                   i.quantity -= quantity;
                   if (i.quantity < 1)
                       FIS_Inventory.remove(i);
                   
                   return;
               }        
       }
       
      
     
       private class DatedItems 
        {
            // Instance variables
            
       private I item;
       
       private boolean isRec = false;
            
       private GregorianCalendar criticalDate;
            
       private int quantity;
            
       private int Stock_Received = 0;
    	
       private int Stock_Requested = 0;
       
       private int Requests_Filled = 0;
    	
       private int Stock_Shipped_Out = 0;
       
       private int Stock_Expired = 0;	
       
       private int Spoilage = 0;
       
       private int Stock_On_Hand = 0;
            
            /**
             * Builds a dated item with the specified item, date, and quantity.
             * 
             * @param item
             *            an item of type I
             * @param criticalDate
             *            the critical date for this item
             * @param quantity
             *            the quantity of this item
             */
            public DatedItems (I item, GregorianCalendar criticalDate, int quantity, boolean isReceived)
            {   
                this.item = item;
                this.criticalDate = criticalDate;
                this.quantity = quantity;
                this.isRec = isReceived;
                
                if(isRec)
                   Stock_Received = quantity;
                      else
                         Stock_Requested = quantity;
                         
            }
            
            public DatedItems() 
            {
            	
    		}

    		public void setStock_Expired(I item, GregorianCalendar criticalDate, int quantity )
            {
            
                 // Check for invalid parameters.
            
            if (item == null || criticalDate == null || quantity < 1)
                return;
            
            // Make a dated item for these parameters.
            
            DatedItems d = new DatedItems (item, criticalDate, quantity, false);
            
            // Try to find it in the inventory.
            
            for (DatedItems i : FIS_Inventory)
                if (i.isSameItemAndDate(d))
                {
                    // Found it - decrease quantity and remove it if quantity falls below 0.
                    
                    i.Stock_Expired = quantity;
                    
                    return;
                } 
            
            
            }
            
            /**
             * Returns true if this dated item and the other dated item share the same items and dates.
             * 
             * @param d
             *            some other dated item
             * @return true if they are equivalent items and dates
             */
            public boolean isSameItemAndDate (DatedItems d)
            {
                return item.getName().equals(d.item.getName()) && criticalDate.equals(d.criticalDate);
            }        
        }


    }
    
}