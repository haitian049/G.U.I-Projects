import java.util.*;




public class FoodItemsStatistics<I extends Item>
{
   
    // Creating a List of DatedItems to represent my FoodItemStatistics Inventory
    protected List<DatedItem> FIS_Inventory;

    /* Constructor */

    /**
     * Builds an empty inventory.
     */
    public FoodItemsStatistics ()
    {
        
    	FIS_Inventory = new ArrayList<DatedItem>();
    	
    }
    

// ACCESSOR FUNCTIONS-------------------------------------------------------------------------------
   

   public List<I> getItemsPastDate(GregorianCalendar targetDate)
    {
        ArrayList<I> result = new ArrayList<I>();
        
        // Find all the past due items.
        
        for (DatedItem i : FIS_Inventory)
        {
        	
        	try
        	{
        	
            if (i.criticalDate.equals(targetDate))
            
                result.add(i.item);
        	}catch(Exception ex){}
      }
        return result;
    }

   public GregorianCalendar getDate(I item)
    {
        GregorianCalendar result = null;
        
        // Optimization loop on item dates for the specified item
        
        for (DatedItem i : FIS_Inventory)
        
            if (i.item.equals(item) && (result == null ))
            
                result = i.criticalDate;
                
        return result;
        
    }
    
    
      public Set<Item> getAllItems() 
      {
       // Created a hash set because every item in inventory is unique
        Set<Item> set = new HashSet<Item>();
        
       // Adds every item in FoodItemStatistics Inventory to the set
        for (DatedItem i : FIS_Inventory)
        {
        	
            set.add(i.item);
        }
       // Returns the set     
        return set;
    }
    
      public int getAllQuanity() 
      {
      // Integer variable to keep count of the total amount of FoodItems in the FoodItemsStatistics_Inventory
        int Total = 0;
     
      // 
        for (DatedItem i : FIS_Inventory)
            Total += i.Stock_On_Hand;
            
        return Total;
    }
    
     public  List<DatedItem> getAllDatedItem() 
    {
        List<DatedItem> fis = FIS_Inventory;
       
        return fis;
        
    }
     
     
     public int getQuantity(I item, GregorianCalendar criticalDate)
     {
         // Check for invalid parameters.
         
         if (item == null || criticalDate == null)
             return 0;
         
         // Make a dated item for these parameters.
         
         DatedItem d = new DatedItem (item, criticalDate, 0);
         
         // Try to find it in the inventory.
         
         for (DatedItem i : FIS_Inventory)
             if (i.isSameItemAndDate(d))
                 return i.Stock_On_Hand;// Found it - return the quantity
         
         // Not found.
         
         return 0;
     }
    
//--------------------------------------------------------------------------------------------------


   public void addItem(I item, GregorianCalendar criticalDate, int quantity, boolean isReceived)
    {
        // Check for invalid parameters.
        
        if (item == null || criticalDate == null || quantity < 1)
        {
        	
            return;
        }
        // Make a dated item for these parameters.
        
        DatedItem d = new DatedItem (item, criticalDate, quantity, isReceived);
        
        // Try to find it in the inventory.
        
        for (DatedItem i : FIS_Inventory)
         
        	
        	{
        	
        	if (i.isSameItemAndDate(d) && !(i.isRec))// If an item is in inventory and only been requested never received
        	{
        		 i.Stock_On_Hand += quantity;
                 
                 i.Stock_Received += quantity;
                
                 i.criticalDate = d.criticalDate;
                 
                 return;
                     
            }
        	   
            // If an item is being received 
        	else if(i.isSameItemAndDate(d) && i.isRec)
            {
                // Found it - increase quantity and quit.
                
                i.Stock_On_Hand += quantity;
                
                i.Stock_Received += quantity;
                
                return;
            }
        	}
        
        // Didn't find it - add it to inventory.
        
        d.setStock_On_Hand(quantity);
        //System.out.print("This is the stocked on hand for an item that was received but not in inventory:   " +  d.Stock_On_Hand);
        
        FIS_Inventory.add(d);
        return;
        
    }
   
     
   public void removeItem(I item, GregorianCalendar criticalDate, int quantity, boolean Req,GregorianCalendar targetDate )
   {
   
        // Check for invalid parameters.
   
   if (item == null || criticalDate == null || quantity < 1)
   {
	   //DatedItem d = new DatedItem (item, criticalDate, quantity);
	   
	  // d.Stock_Requested = quantity;
	   
	   FIS_Inventory.add(new DatedItem (item, criticalDate, quantity, Req));
	   
	   return;
   }
       
   
   // Make a dated item for these parameters.
   
   DatedItem d = new DatedItem (item, criticalDate, quantity);
   
   
   // Try to find it in the inventory.
   
   for (DatedItem i : FIS_Inventory)
   {
	   
	   if (i.isSameItemAndDate(d) && !(i.isRec))// If an item is in inventory and only been requested never received
       {
           // Found it - decrease quantity and remove it if quantity falls below 0.
           
    	   
    	   i.Stock_Requested += quantity;
            
    	   i.criticalDate = d.criticalDate;
    	   
    	   
           return;
           
           
       }
	   
	   if(i.isSameItemAndDate(d))// If an item is in inventory and has been received
	   {
		   
		   
		   i.Stock_Requested += quantity;
		   
		   //if(!(i.criticalDate.before(targetDate)))
		  // i.Stock_Shipped_Out = quantity; i.Stock_Expired -= quantity;
		   
		   if(i.Stock_On_Hand > quantity)
 		   {
 			   
 	           i.Stock_Expired = (i.Stock_Received - quantity);
 	           
 	           i.Stock_Shipped_Out += quantity;
 	           
 	           i.Stock_On_Hand = 0;
 	           
 		   }
 		   
		   else if(i.Stock_On_Hand < quantity && i.criticalDate.before(targetDate))
		   {
			   
			   //i.Stock_Shipped_Out = i.Stock_Received;;
			   
			   i.backOrder = (quantity - i.Stock_On_Hand);
			   
			   i.Stock_On_Hand = 0;
			   
			   
		   }
		   
		   /*if(i.Stock_On_Hand > d.Stock_Requested)
		   {
			   
	           i.Stock_Shipped_Out = (i.Stock_On_Hand - d.Stock_Requested);
	           
	           i.Stock_On_Hand-=d.Stock_Requested;
	           
		   }
		   else
		   {
			   
			   i.Stock_Shipped_Out += i.Stock_On_Hand;
			   
			   i.backOrder += (d.Stock_Requested - i.Stock_On_Hand);
			   
			   i.Stock_On_Hand = 0;
			   
		   }*/
		   
		   return;
	   }
   } 
   
   	 /* d.Stock_Requested = quantity;
   	  d.Stock_On_Hand = 0;
      FIS_Inventory.add(d);
     */	
  
   }
 
   public class DatedItem 
    {
        public int backOrder;

		// Instance variables
        
   private I item;
   
   private boolean isRec = false, isExp = false;
        
   private GregorianCalendar criticalDate;
        
   public int Stock_Received;
	
   private int Stock_Requested;
   
   private int Requests_Filled;
	
   private int Stock_Shipped_Out;
   
   private int Stock_Expired;	
   
   private int Spoilage;
   
   private int Stock_On_Hand;
        
        /**
         * Builds a dated item with the specified item, date, and quantity.
         * 
         * @param item
         *            an item of type I
         * @param criticalDate
         *            the critical date for this item
         * @param quantity
         *            the quantity of this item
         */
   
   //------------------------------------------------------------CONSTRUCTORS-------------------------------------------------------------------------------------
        
        
public DatedItem() 
{
        	   
            	this.item = null;
            
        	criticalDate = null;
    
       
        	this.Stock_On_Hand = 0;
        	
        	
        	this.isRec = false;
    
   
  Requests_Filled = 0;
	
  Stock_Shipped_Out = 0;
   
  Stock_Expired = 0;;	
   
  Spoilage = 0;
   
  Stock_On_Hand = 0;
        
            
 }
        
 public DatedItem (I item, GregorianCalendar criticalDate, int quantity)
 {   
            
  this.item = item;
           
  this.criticalDate = criticalDate;
            
  this.Stock_On_Hand = quantity;
                     
  this.Requests_Filled = 0;
	
  this.Stock_Shipped_Out = 0;
   
  this.Stock_Expired = 0;;	
   
  this.Spoilage = 0;
   
  this.Stock_On_Hand = 0;
                     
 }
        
 
        
        
        public DatedItem (I item, GregorianCalendar criticalDate, int quantity, boolean isReceived)
        {   
           
        	this.item = item;
            
        	if(criticalDate == null)
        	{
       
        	this.Stock_On_Hand = 0;
        	
        	}
        		else
        		{
        			this.criticalDate = criticalDate;
        			
        			this.Stock_On_Hand = quantity;
        		}
        	
        	this.isRec = isReceived;
            
           if(isRec)
               this.Stock_Received = quantity;
                  else
                     this.Stock_Requested = quantity;
                     
  
   
  Requests_Filled = 0;
	
  Stock_Shipped_Out = 0;
   
  Stock_Expired = 0;;	
   
  Spoilage = 0;
   
  Stock_On_Hand = 0;
        
            
        }
        
      
 //-----------------------------------------------------------------------------------------------------------------------------------------
        
        public Inventory.FoodItem getItem()
        {
        	
        	return (Inventory.FoodItem) item;
        }
        
        public int getStock_Received()
        {
           return Stock_Received;
        }
     	
        public int getStock_Requested()
        {
           return Stock_Requested;
        }
        
        public int getRequests_Filled()
     	{
           return Requests_Filled;
        }
        
        public int getStock_Shipped_Out()
        {
           return Stock_Shipped_Out;
        }
        
        public int getStock_Expired()	
        {
           return Stock_Expired;
        }
        
        public int getSpoilage()
        {
           return Spoilage;
        }
        
        public int getStock_On_Hand()
        {
           return Stock_On_Hand;
        }
        
  //-----------------------------------------------------------------------------------------------------------------------------------------
        
        public void Stock_Received(int SR)
        {
           Stock_Received = SR;
        }
     	
        public void Stock_Requested(int SR)
        {
           Stock_Requested = SR;
        }
        
        public void Requests_Filled(int RF)
     	{
            Requests_Filled = RF;
        }
        
        public int void_Shipped_Out()
        {
           return Stock_Shipped_Out;
        }
        
        public void setStock_Expired(int SE)	
        {
           Stock_Expired = SE;
        }
        
        public void voidSpoilage(int S)
        {
           Spoilage = S;
        }
        
        public void setStock_On_Hand(int SOH )
        {
           Stock_On_Hand = SOH;
        }
        
		public void setStock_Expired(I item, GregorianCalendar criticalDate, int quantity )
        {
        
             // Check for invalid parameters.
        
        if (item == null || criticalDate == null || quantity < 1)
            return;
        
        // Make a dated item for these parameters.
        
        DatedItem d = new DatedItem (item, criticalDate, quantity, false);
        
        // Try to find it in the inventory.
        
        for (DatedItem i : FIS_Inventory)
            if (i.isSameItemAndDate(d))
            {
                // Found it - decrease quantity and remove it if quantity falls below 0.
                
                i.Stock_Expired = quantity;
                
                i.Stock_On_Hand -= i.Stock_Expired;
                
                i.isExp = true;
                
              
            }
        
        }
		
		/**
         * Returns true if this dated item and the other dated item share the same items and dates.
         * 
         * @param other
         *            some other dated item
         * @return true if they are equivalent items and dates
         */
        public boolean isSameItemAndDate (DatedItem other)
        {
            return item.getName().equals(other.item.getName()); //&& criticalDate.equals(other.criticalDate);
        }        
    }


}