import java.util.*;
import java.util.List;
import java.io.*;
import java.text.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;






//import FoodItemsStatistics.DatedItem;

/**
 * This class parses the transaction file. It calls the appropriate method to handle 
 * each transaction record.
 */
public class TransactionReader<I extends Item>
{
	 static JFrame frame = new JFrame();
	 
	 private JPanel mainPanel = new JPanel(new BorderLayout());

	 private JButton retrieveButton = new JButton("Close Transactions");
	 
	 

	 private Scanner scan;

     private HashMap<String, Inventory<Inventory.FoodItem>> warehouses;
     
     private TreeMap<String, Inventory.FoodItem> foodItems;
     
     private TreeMap<String, FoodItemsStatistics<Inventory.FoodItem>> foodItemsStats;

	 private Date transactionDate = null;
	
	 private GregorianCalendar calendar = null;

	 private int num = 0;
	
	TextArea textArea = null;
	
/**
 * This constructor instantiates two HashMaps; one to store the names of warehouses
 * along with their inventory, and another one to store the UPC along with the 
 * FoodItem.
 */
	public TransactionReader(File file) throws FileNotFoundException
	{
		  scan = new Scanner(file);
		  
		  warehouses = new HashMap<String, Inventory<Inventory.FoodItem>>();
		  
		  foodItems  = new TreeMap<String, Inventory.FoodItem>();
		
		  foodItemsStats = new TreeMap<String, FoodItemsStatistics<Inventory.FoodItem>>();
	
		  final JPanel panel = new JPanel();
		  
		  frame.setSize(800,800);
	        
	      panel.setPreferredSize(new Dimension(400, 300));
	        
	      panel.setBackground(Color.white);
	        
	      frame.getContentPane().add(panel, BorderLayout.CENTER);
			  
	      textArea = new TextArea("", 0,0, TextArea.SCROLLBARS_VERTICAL_ONLY);

	      frame.getContentPane().add(textArea);
	        
	      JMenuBar menuBar = new JMenuBar(); // first, create a MenuBar item
	        
	      JMenu file1 = new JMenu(); // our File menu
	        
	        // what's going in File? let's see...
	        
	        //a group of JMenuItems
	      JMenuItem openFile = new JMenuItem();  // an open option
	        
	      JMenuItem saveFile = new JMenuItem(); // a save option
	        
	      JMenuItem close = new JMenuItem(); // and a close option!

	      menuBar.add(file1); // we'll configure this later
	        
	   // first off, the design of the menuBar itself. Pretty simple, all we need to do
	       
          // is add a couple of menus, which will be populated later on
 
          file1.setText("File");
  

  
          // time for the repetitive stuff. let's add the "Open" option
  
          openFile.setText("Open"); // set the label of the menu item
  
          file1.add(openFile); // add it to the "File" menu

          // and the save...
  
          saveFile.setText("Save");
  
          file1.add(saveFile);

          // and finally, the close option
  
          close.setText("Close");
 
          file1.add(close);

          openFile.addActionListener(new ActionListener()
      	{  

      	public void actionPerformed(ActionEvent e)
      	   {
      		JFileChooser open = new JFileChooser(); // open up a file chooser (a dialog for the user to browse files to open)
      		
      		            int option = open.showOpenDialog(open); // get the option that the user selected (approve or cancel)
      		
      		            // NOTE: because we are OPENing a file, we call showOpenDialog~
      		
      		            // if the user clicked OK, we have "APPROVE_OPTION"
      		
      		            // so we want to open the file
      		
      		            if (option == JFileChooser.APPROVE_OPTION) {
      		
      		                textArea.setText(""); // clear the TextArea before applying the file contents
      		
      		                try {
      		
      		                    // create a scanner to read the file (getSelectedFile().getPath() will get the path to the file)
      		
      		                    Scanner scan = new Scanner(new FileReader(open.getSelectedFile().getPath()));
      		
      		                    while (scan.hasNext()) // while there's still something to read
      		
      		                        textArea.append(scan.nextLine() + "\n"); // append the line to the TextArea
      		
      		                } catch (Exception ex) { // catch any exceptions, and...
      		
      		                    // ...write to the debug console
      		
      		                    System.out.println(ex.getMessage());
      		
      		                }
      		
      		            }

      	   }
      	});
      	
      	
      	// add an action listener (so we know when it's been clicked
      	saveFile.addActionListener(new ActionListener()
      	{  

      	public void actionPerformed(ActionEvent e)
      	   {
      		JFileChooser save = new JFileChooser(); // again, open a file chooser
      		
      		int option = save.showSaveDialog(save);
      		
      		if (option == JFileChooser.APPROVE_OPTION) {
      			
      			                try {
      			
      			                    // create a buffered writer to write to a file
      			
      			                    BufferedWriter out = new BufferedWriter(new FileWriter(save.getSelectedFile().getPath()));
      			
      			                   out.write(((TextComponent)textArea).getText()); // write the contents of the TextArea to the file
      			
      			                    out.close(); // close the file stream
      			
      			                } catch (Exception ex) { // again, catch any exceptions and...
      			
      			                    // ...write to the debug console
      			
      			                    System.out.println(ex.getMessage());
      		
      			                }
      			
      			            }

      	   }
      	
      	});
      	
      	close.addActionListener(new ActionListener()
      	{  
      		
      		public void actionPerformed(ActionEvent e)
      	   {
      			
      		        frame.dispose();
      		        
      	   }

      	
      	});
      		  


      	//Add the menu mar to the frame	
          frame.setJMenuBar(menuBar);
          

	}

	/**
	 * Reads the transaction file and calls the appropriate method. 
	 */
	
	public void readAllTransactions()
	{
		String line;
		while(scan.hasNextLine())
		{
			line = scan.nextLine();
			if(line.startsWith("FoodItem - "))			readFoodItem(line);
			else if(line.startsWith("Warehouse - "))	readWarehouse(line);
			else if(line.startsWith("Start date: "))	readStartDate(line);
			else if(line.startsWith("Receive: "))		readReceive(line);
			else if(line.startsWith("Request: "))		readRequest(line);
			else if(line.startsWith("Next day:"))		readNextDay(line);
			else if(line.startsWith("End"))				readEnd(line, textArea);
			else System.out.println("Unrecognized Transaction");
		}	
		
		// Writes backup report to a file even if save is not requested
       String Line = null;
		 
       try{
      
       BufferedWriter writer = writer = new BufferedWriter(new FileWriter("outputfile3_Report"));
   
       //----------------------------------------------------------------------------------------- 
        for (String warehouseName : foodItemsStats.keySet())
        {
            
            FoodItemsStatistics<Inventory.FoodItem> FIS_Inventory = foodItemsStats.get(warehouseName);
            
            //System.out.println("\n------------------------------------------------------\n"+warehouseName+"\n------------------------------------------------------");
            
             Line = "------------------------------------------------------";
             
             writer.write(Line);
             
             writer.newLine();
        
             Line = warehouseName;
              
             writer.write(Line);
             
             writer.newLine();

             Line = "------------------------------------------------------";
             
             writer.write(Line);
             
             writer.newLine();

            List<FoodItemsStatistics<Inventory.FoodItem>.DatedItem> fis = FIS_Inventory.getAllDatedItem();
            
            for (FoodItemsStatistics<Inventory.FoodItem>.DatedItem DatedItem : fis)
            {    
                     
            		String fooditem_nane = (String)DatedItem.getItem().getName();
            		
            			//System.out.println( upc + "\nStock Received:" + DatedItem.getStock_Received() + "\n\nStock Expired: " + DatedItem.getStock_Expired() + "\n\nStock Requested: " + DatedItem.getStock_Requested() + "\n\nStock On Hand: " + DatedItem.getStock_On_Hand() + "\n\nStock Shipped Out: " + DatedItem.getStock_Shipped_Out() + "\n\n");
                           
               writer.write(fooditem_nane);
	        	   
               writer.newLine();writer.newLine();
               
               Line = "  Stock Received:" + DatedItem.getStock_Received(); 
                                 
               writer.write(Line);
	        	   
               writer.newLine();writer.newLine();

               
               Line = "  Stock Expired: " + DatedItem.getStock_Expired();
	            
               writer.write(Line);
               
               writer.newLine();writer.newLine();
               
               Line = "  Stock Requested: " + DatedItem.getStock_Requested(); 
               
               writer.write(Line);
               
               writer.newLine();writer.newLine();
               
               Line = "  Stock On Hand: " + DatedItem.getStock_On_Hand(); 
                  
               writer.write(Line);   
                              
               writer.newLine();writer.newLine();
               
               Line = "  Stock Shipped Out: " + DatedItem.getStock_Shipped_Out();

               writer.write(Line);
                
               writer.newLine();writer.newLine();
               
               writer.newLine();writer.newLine();
               
               
            }
				
        }
        
        writer.close();
        
        }catch(Exception ex){ex.printStackTrace();}

		 			
		
	}

	/**
	 * Reads and parses the food item record. Add code in this method to store
	 * the UPC code along with the FoodItem. 
	 */
	public void readFoodItem(String line)
	{
		
      Scanner parser = new Scanner(line);
		parser.next();
		parser.next();
		parser.next();
		parser.next();
		String upc = parser.next().trim();
		parser.next();
		parser.next();
		int shelfLife = new Integer(parser.next()).intValue();
      
      //Inventory inventory = new Inventory();
      
		parser.next();
      
		String name = parser.nextLine().trim();
       
		foodItems.put(upc, new Inventory.FoodItem(name, upc, shelfLife));
  
	}
	
	/**
	 * Reads and parses the warehouse record. Add code in this method to store the 
	 * warehouse name and a new Inventory object.
	 */
	public void readWarehouse(String line)
	{
		Scanner parser = new Scanner(line);
		parser.next();
		parser.next();
		String name = parser.next().trim();
		
		warehouses.put(name, new Inventory<Inventory.FoodItem>());
		
		//FoodItemsStatistics<Inventory.FoodItem> fis = null;
		
       foodItemsStats.put(name, new FoodItemsStatistics<Inventory.FoodItem>());
      
      
	}
	
	/**
	 * Reads and parses the start date record and creates a GergorianCalendar object
	 * representing the start date. 
	 */
	public void readStartDate(String line)
	{
		Scanner parser = new Scanner(line);
		
      parser.next();
		
      parser.next();
		
      String d = parser.next().trim();
		
      try
      { 
      
      transactionDate = new SimpleDateFormat("MM/dd/yyyy").parse(d);
      
      }
		catch(ParseException e)
      {
      
         System.out.println("Could not parse date ");
         
      }
		
      calendar = new GregorianCalendar();
		
      calendar.setTime(transactionDate);
	}
	
	/**
	 * Reads and parses the receive food item record. Add code in this method to add
	 * food items to the inventory. Use the {@link Inventory#addItem} method.
	 */
	public void readReceive(String line)
	{
		Scanner parser = new Scanner(line);
		
      parser.next();
		
      String upc = parser.next().trim(); 
		
      int quantity = new Integer(parser.next().trim()).intValue();
		
      String warehouse = parser.next().trim();
		
      Inventory<Inventory.FoodItem> inventory = warehouses.get(warehouse);
      
      FoodItemsStatistics<Inventory.FoodItem> fis_inventory = foodItemsStats.get(warehouse);

      Inventory.FoodItem f_item = foodItems.get(upc);
		      
      inventory.addItem(f_item, f_item.getExpirationDate(calendar), quantity);
      
      fis_inventory.addItem(f_item, f_item.getExpirationDate(calendar), quantity, true);
	}
	
	/**
	 * Reads and parses the request food item record. Add code in this method to remove
	 * food items from inventory. Remember to remove oldest items first that have not
	 * already expired. Use the {@link Inventory#removeItem} method.
 	 */
	public void readRequest(String line)
	{
		Scanner parser = new Scanner(line);
     
      int qty = 0;
		
      GregorianCalendar date = null;
      
      parser.next();
		
      String upc = parser.next().trim(); 
		
      int quantityRequested = new Integer(parser.next()).intValue();
		
      String warehouse = parser.next().trim(); 
		
      Inventory<Inventory.FoodItem> inventory = warehouses.get(warehouse);
      
      FoodItemsStatistics<Inventory.FoodItem> fis_inventory = foodItemsStats.get(warehouse);
		
      Inventory.FoodItem item = foodItems.get(upc);
      
      GregorianCalendar date1 = fis_inventory.getDate(item);//item.getExpirationDate(calendar);
	
      date = inventory.getDate(item);
			
      qty = inventory.getQuantity(item, date);
         
      qty -= quantityRequested;
        	
      inventory.removeItem(item, date, qty);
            
	  System.out.println("removeItem from fis_9nventory executing..............." + num ++);
            
      fis_inventory.removeItem(item, date1, quantityRequested, false, calendar); //nextDay);
               
         
	}
	
	/**
	 * Reads and parses the next day record and advances the current day by one day.
	 */
	public void readNextDay(String line)
	{
		Scanner parser = new Scanner(line);
      
      int expired_qty = 0;
      
      List<Inventory.FoodItem> expired_Items = new ArrayList<Inventory.FoodItem>();
      
		String nextday = parser.nextLine().trim(); 
      
		calendar.add(Calendar.DAY_OF_MONTH, 1);
      
		GregorianCalendar nextDay = (GregorianCalendar) calendar.clone();
      
		//nextDay.add(Calendar.DAY_OF_MONTH, 1);

      for (FoodItemsStatistics<Inventory.FoodItem> FIS_Inventory : foodItemsStats.values())
		{
    	  
    	  FoodItemsStatistics<Inventory.FoodItem> fis = FIS_Inventory;
    	    
		    // get all past date items, (because item expired at start of the day)
		    // the expiration day need to < nextDay
	        expired_Items = fis.getItemsPastDate(nextDay);
           
	        for (Inventory.FoodItem fd : expired_Items)
	        {
	        	
	        	FoodItemsStatistics<Inventory.FoodItem>.DatedItem DI  = fis.new DatedItem();
	        	
	            GregorianCalendar rdate = FIS_Inventory.getDate(fd);

	            expired_qty = FIS_Inventory.getQuantity(fd, rdate);
               
	            DI.setStock_Expired(fd, rdate, expired_qty);
              
	        }
           		    
		}

      
		for (Inventory<Inventory.FoodItem> inventory : warehouses.values())
		{
         
		    // get all past date items, (because item expired at start of the day)
		    // the expiration day need to < nextDay
	        expired_Items = inventory.getItemsPastDate(nextDay);
           
	        for (Inventory.FoodItem fd : expired_Items)
	        {
	            GregorianCalendar rdate = inventory.getDate(fd);
               
	          int expired_qty1 = inventory.getQuantity(fd, rdate);
               
	            inventory.removeItem(fd, rdate, expired_qty1);
	        }
           		    
		}
      
	}
	
	/**
	 * Reads the end of transaction records.
	 * @param textArea 
	 */
	public void readEnd(String line, TextArea textArea)
	{
		Scanner parser = new Scanner(line);
		String end = parser.next().trim(); 
		
		
	      textArea.append("***********************************************************************************************************************************************************\n");
			textArea.append("			Food Item Statistics Report \n");
			textArea.append("    			as of : 05/04/2010\n");
			textArea.append("   			All Warehouses Reporting \n");
	      textArea.append("***********************************************************************************************************************************************************\n");
			
	      for (String warehouseName : foodItemsStats.keySet())
	      {
	            FoodItemsStatistics<Inventory.FoodItem> FIS_Inventory = foodItemsStats.get(warehouseName);
	            
	        textArea.append("\n------------------------------------------------------\n"+warehouseName+"\n------------------------------------------------------");
			
            List<FoodItemsStatistics<Inventory.FoodItem>.DatedItem> fis = FIS_Inventory.getAllDatedItem();
            
            for (FoodItemsStatistics<Inventory.FoodItem>.DatedItem DatedItem : fis)
            {    
                     
            		String fooditem_nane = (String)DatedItem.getItem().getName();
            		
	        textArea.append("\n	"+ DatedItem.getItem().getUpcCode() + "	" +  fooditem_nane);
			textArea.append("\n 							Stock Received: " + DatedItem.getStock_Received());
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
			textArea.append("\n			");
            }
            
	      }
	}
	
	public static void main(String[] args)throws FileNotFoundException
	{
		TransactionReader tr = 	new TransactionReader(new File("data3.txt"));
		tr.readAllTransactions();	
		
		frame.setSize(800,800);
   		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   		frame.pack();
         frame.setVisible(true);
	}

}

